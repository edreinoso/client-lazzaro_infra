hello='frontend-code-build-service/client2.json'

hello.split('/')

hello1=hello.split('/')[1]

hello1.split('.')

print(hello1.split('.')[0])

tags = [
        {
            'key': 'Name',
            'value': 'client'
        },
        {
            'key': 'Port',
            'value': 'port'
        },
        {
            'key': 'Date',
            'value': 'date'
        },
    ]

print(tags)