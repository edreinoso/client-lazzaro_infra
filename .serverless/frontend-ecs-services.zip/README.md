# Lazzaro Frontend Deployment


## Architecture
![aws-devops](https://personal-website-assets.s3.amazonaws.com/Projects/fda.jpeg)