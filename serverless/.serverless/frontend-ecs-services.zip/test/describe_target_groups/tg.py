import boto3
import logging

logger = logging.getLogger()

elb_client = boto3.client('elbv2')

alb_arn = "arn:aws:elasticloadbalancing:eu-central-1:648410456371:loadbalancer/app/lazzaro-front-alb-pre/7e4a3f58837bf426"
target_name = "hello"

targetg = elb_client.describe_target_groups(
    Names=[target_name]
)
target_arn = targetg['TargetGroups'][0]['TargetGroupArn']

print(target_arn)